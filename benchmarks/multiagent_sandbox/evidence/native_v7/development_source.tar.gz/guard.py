"""Fail fast on infrastructure errors; never reinterpret raw task outcomes."""


def infrastructure_failure(row):
    if row.get("error"):
        return str(row["error"])
    for step in row.get("result", {}).get("steps", []):
        error = step.get("response", {}).get("error")
        if error:
            return str(error)
    return None


def require_healthy(row):
    error = infrastructure_failure(row)
    if error:
        raise RuntimeError(
            "Inference infrastructure failure; episode retained, run stopped: " + error
        )
