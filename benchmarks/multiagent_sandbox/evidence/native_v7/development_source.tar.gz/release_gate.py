"""Experimental structured-output release gate, not a general semantic verifier.

Trusted adapters supply facts, task scope and current authority state. Model
proposals never define permissions. No free-form model text is released. The
caller must serialize authority checking with actual release; this pure function
does not provide a database transaction or coverage of bypass channels.
"""

from __future__ import annotations

import json

FALLBACK = "Information unavailable for this request; contact the account owner."
MODES = ("snapshot", "fresh_policy", "fresh_scope", "full", "deny_all")


def evaluate(proposal, task, facts, authority, mode="full"):
    """Return local release result. Only center_summary may cross to the auditor.

    Partial arms are explicit ablations of this code, NOT replicas of other papers.
    Exact value equality checks source support only, not external factual truth.
    """
    if mode not in MODES:
        raise ValueError("unknown evaluation mode")

    def result(status, reason, released=()):
        released = list(released)
        return {
            "status": status,
            "reason": reason,
            "released": released,
            "answer": "; ".join(f"{r['field']}: {r['value']}" for r in released)
            if released
            else FALLBACK,
            "center_summary": {
                "schema": "structured-release/v1",
                "status": status,
                "reason": reason,
            },
        }

    if mode == "deny_all":
        return result("unknown", "disabled")
    if isinstance(proposal, str):
        try:
            proposal = json.loads(proposal)
        except (ValueError, TypeError):
            return result("unknown", "invalid_schema")
    if not isinstance(proposal, dict) or set(proposal) != {"claims"}:
        return result("unknown", "invalid_schema")
    claims = proposal["claims"]
    if not isinstance(claims, list) or not 1 <= len(claims) <= 8:
        return result("unknown", "missing_claims")
    accepted = []
    for claim in claims:
        if (
            not isinstance(claim, dict)
            or set(claim) != {"source_id", "version", "field", "value"}
            or any(type(claim[k]) is not str for k in ("source_id", "field", "value"))
            or type(claim["version"]) is not int
        ):
            return result("unknown", "invalid_schema")
        fact = facts.get(claim["source_id"])
        if fact is None or not fact.get("trusted", False):
            return result("unknown", "untrusted_source")
        if fact["workspace"] != task["workspace"]:
            return result("deny", "workspace_mismatch")
        if mode == "snapshot":
            grants = fact["snapshot_grants"]
        else:
            state = authority.get(claim["source_id"])
            if state is None or not state.get("available", False):
                return result("unknown", "authority_unavailable")
            if state["deleted"]:
                return result("deny", "deleted_source")
            if claim["version"] != state["version"] or fact["version"] != state["version"]:
                return result("unknown", "version_mismatch")
            grants = state["grants"]
        if task["recipient"] not in grants:
            return result("deny", "unauthorized_recipient")
        field = claim["field"]
        if mode in ("fresh_scope", "full"):
            if fact["case"] != task["case"]:
                return result("deny", "case_mismatch")
            if field not in task["fields"] or task["purpose"] not in fact["purposes"].get(
                field, []
            ):
                return result("deny", "purpose_mismatch")
        if mode == "full":
            if field not in fact["values"] or claim["value"] != fact["values"][field]:
                return result("unknown", "unsupported_value")
        accepted.append(claim)
    return result("allow", "validated_projection", accepted)
