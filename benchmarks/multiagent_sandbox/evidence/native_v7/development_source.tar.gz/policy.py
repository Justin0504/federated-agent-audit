"""Task-bound destination capabilities, not semantic content verification.

No benchmark injection labels, ground-truth actions, or security oracles are
available to this adapter. Only the trusted original request can grant a
literal destination. Implicit contacts deliberately remain unresolved.
"""

import re
from release_gate import evaluate

EGRESS = {
    "send_email": ("recipients", "cc", "bcc"),
    "post_webpage": ("url",),
    "send_direct_message": ("recipient",),
    "send_channel_message": ("channel",),
    "share_file": ("email",),
}
INTENT = re.compile(
    r"\b(send|share|forward|reply|post|tell|message|email|notify|remind|inform|respond)\b", re.I
)


def decide(function, args, request, mode):
    if function not in EGRESS or mode == "no_gate":
        return {
            "status": "allow",
            "reason": "not_mediated" if function not in EGRESS else "disabled",
        }
    if mode == "deny_egress":
        return {"status": "unknown", "reason": "deny_egress"}
    intent = bool(INTENT.search(request))
    destinations = []
    for key in EGRESS[function]:
        values = args.get(key, [])
        if isinstance(values, str):
            values = [values]
        if not isinstance(values, list) or any(not isinstance(v, str) for v in values):
            return {"status": "unknown", "reason": "invalid_destinations"}
        destinations.extend(values)
    if not destinations:
        return {"status": "unknown", "reason": "missing_destination"}
    bound = all(
        bool(d.strip()) and re.search(r"(?<!\w)" + re.escape(d.strip()) + r"(?!\w)", request, re.I)
        for d in destinations
    )
    authorized = {"intent_only": intent, "destination_only": bound, "combined": intent and bound}[
        mode
    ]
    # Reuse the frozen gate on the destination-authority envelope only.
    # No representation here asserts that the MESSAGE BODY has source support.
    facts = {
        "envelope": {
            "trusted": True,
            "workspace": "task",
            "case": "request",
            "version": 1,
            "snapshot_grants": [],
            "values": {"recipient": "outbound"},
            "purposes": {"recipient": ["communication"]},
        }
    }
    task = {
        "workspace": "task",
        "case": "request",
        "recipient": "outbound",
        "purpose": "communication",
        "fields": ["recipient"],
    }
    authority = {
        "envelope": {
            "available": True,
            "version": 1,
            "deleted": False,
            "grants": ["outbound"] if authorized else [],
        }
    }
    proposal = {
        "claims": [
            {"source_id": "envelope", "version": 1, "field": "recipient", "value": "outbound"}
        ]
    }
    result = evaluate(proposal, task, facts, authority)
    return {
        "status": result["status"],
        "reason": "task_bound" if authorized else "unbound_destination_or_intent",
    }
