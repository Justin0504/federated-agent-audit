"""File-RPC worker, inference on the same Jetstream VM only."""

import json
import time
from pathlib import Path
from backend import generate, post

root = Path(__file__).resolve().parent
p = json.loads((root / "protocol.json").read_text())
ex = root / "exchange"
ex.mkdir(exist_ok=True)
post("/tokenize", {"content": "readiness"})
(ex / "READY").write_text("remote-only llama.cpp ready")
while True:
    for f in sorted(ex.glob("*.request.json")):
        out = f.with_name(f.name.replace(".request.json", ".response.json"))
        if out.exists():
            continue
        req = json.loads(f.read_text())
        if req["op"] == "stop":
            raise SystemExit(0)
        result = generate(req["messages"], p)
        tmp = out.with_suffix(".tmp")
        tmp.write_text(json.dumps(result))
        tmp.rename(out)
        if result.get("error"):
            raise SystemExit("Inference error saved; worker stopped")
    time.sleep(0.1)
